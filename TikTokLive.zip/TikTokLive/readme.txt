git clone https://github.com/isaackogan/TikTokLive.git
cd TikTokLive
python setup.py

python -m pip install pygame
