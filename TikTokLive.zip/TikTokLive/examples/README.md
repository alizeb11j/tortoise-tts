Examples
======

### Current Examples
    
- [Basic Implementation](basic.py)
- [Downloading Avatars](avatars.py)
- [Download Stream Video](download.py)
- [Reading From GiftEvent](gifts.py)
- [Using with Pygame](pygamex.py)

### Contributing Examples

Create a [pull request](https://github.com/isaackogan/TikTok-Live-Connector/pulls) & I will add your example when I have free time!
