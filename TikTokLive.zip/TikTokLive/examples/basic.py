from TikTokLive import TikTokLiveClient
from TikTokLive.types.events import CommentEvent, ConnectEvent
from TikTokLive.types.events import GiftEvent
from pygame import mixer 

  
# Starting the mixer 

path=""
path_rose="Rose.mp3"
path_star="Star.mp3"
path_GG="GG.mp3"
path_live="Live.mp3"
path_heart="Heart.mp3"
path_fire="Fire.mp3"
path_doughnut="Doughnut.mp3"
path_unknown="unknown.mp3"
  
def get_path(giftname):

    if(giftname=="Rose"):
        path=path_rose
    elif(giftname=="GG"):
        path=path_GG
    elif(giftname=="Star"):
        path=path_star
    elif(giftname=="LIVE Fest"):
        path=path_live
    elif(giftname=="Heart Me"):
        path=path_heart
    elif(giftname=="Fire"):
        path=path_fire
    elif(giftname=="Doughnut"):
        path=path_doughnut
    else:
        path=path_unknown
    return path


# Instantiate the client with the user's username
client: TikTokLiveClient = TikTokLiveClient(unique_id="@instinctpromo")


# Define how you want to handle specific events via decorator
@client.on("connect")
async def on_connect(_: ConnectEvent):
    mixer.init()
    print("Connected to Room ID:", client.room_id)


# Notice no decorator?
# async def on_comment(event: CommentEvent):
#     print(f"{event.user.nickname} -> {event.comment}")


# # Define handling an event via "callback"
# client.add_listener("comment", on_comment)

@client.on("gift")
async def on_gift(event: GiftEvent):


    # Streakable gift & streak is over
    if event.gift.streakable and not event.gift.streaking:
        print(f"{event.user.unique_id} sent {event.gift.count}x \"{event.gift.info.name}\"")
        PATH=get_path(event.gift.info.name)
        mixer.music.stop()
        mixer.music.load(PATH)
        mixer.music.play()


    # Non-streakable gift
    elif not event.gift.streakable:
        print(f"{event.user.unique_id} sent \"{event.gift.info.name}\"")
        PATH=get_path(event.gift.info.name)
        mixer.music.load(PATH)
        mixer.music.play()

    
    

if __name__ == '__main__':
    # Run the client and block the main thread
    # await client.start() to run non-blocking
    client.run()
