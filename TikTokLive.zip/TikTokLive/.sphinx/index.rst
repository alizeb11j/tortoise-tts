.. MD -> .. mdinclude:: ../README.md

TikTokLive Docs
==================

.. toctree::
   :maxdepth: 3

   TikTokLive

View the above tree for detailed documentation on the package.

.. include:: ../README.md
   :parser: myst_parser.sphinx_
