# protoc -I. --python_out=. ./tiktok_schema.proto
